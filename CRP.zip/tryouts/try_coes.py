A=['spam']
B=A
B[0]='shrubbery'
print(A)