color1={'k-','k--','g-','g--','b-','b--'};
color2={'c-','c--','m-','m--','r-','r--'};
close all
for i=1:6
    plot(e2s1(i,:),color1{i},'Linewidth',2);hold on;
    plot(e2s2(i,:),color2{i},'Linewidth',2);hold on;
end
